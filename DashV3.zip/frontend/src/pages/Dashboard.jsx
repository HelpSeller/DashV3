import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../services/api";
import Plot from "react-plotly.js";
import CountUp from "react-countup";
import "./Dashboard.css";

export default function Dashboard() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [faturamento, setFaturamento] = useState(null);
  const [frete, setFrete] = useState(null);
  const [devolucao, setDevolucao] = useState(null);
  const [produtosSemVenda, setProdutosSemVenda] = useState(0);
  const [notificacoes, setNotificacoes] = useState(3);
  const [graficoCategoria, setGraficoCategoria] = useState(null);
  const [graficoMarketplace, setGraficoMarketplace] = useState(null);
  const [graficoMensal, setGraficoMensal] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const schema = localStorage.getItem("schema");

    if (!token || !schema) {
      navigate("/login");
      return;
    }

    async function fetchData() {
      try {
        const headers = {
          Authorization: `Bearer ${token}`,
          "x-schema": schema,
        };
        const res = await api.get("/dashboard", { headers });
        const data = res.data;

        setFaturamento(data.faturamento);
        setFrete(data.frete);
        setDevolucao(data.devolucao);
        setProdutosSemVenda(data.produtosSemVenda);
        setGraficoCategoria(data.grafico_categoria);
        setGraficoMarketplace(data.grafico_marketplace);
        setGraficoMensal(data.grafico_mensal);
        setLoading(false);
      } catch (err) {
        console.error("Erro ao carregar dashboard", err);
        if (err.response?.status === 401) {
          navigate("/login");
        }
      }
    }

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="loading-screen">
        <div className="spinner" />
        <p>Carregando dashboard...</p>
      </div>
    );
  }

  return (
    <div className="dashboard-container">
      <div className="dashboard-row">
        <Card
          title="💰 Faturamento"
          value={faturamento?.valor_atual || 0}
          sub={faturamento?.indicador}
          color={faturamento?.cor || "text-white"}
          isCurrency
        />
        <Card
          title="🚚 Frete"
          value={frete?.valor_atual || 0}
          color="text-green-500"
          isCurrency
        />
        <Card
          title="🔁 Devoluções"
          value={devolucao?.valor_atual || 0}
          sub={`📦 ${devolucao?.qtd || 0} devoluções`}
          color="text-red-500"
          isCurrency
        />
        <Card
          title="📦 Produtos Sem Vendas"
          value={produtosSemVenda}
          sub="Com estoque > 0"
          color="text-yellow-400"
        />
        <Card
          title="🔔 Notificações"
          value={notificacoes}
          sub="Gerencie tarefas"
          color="text-white"
          isButton
        />
      </div>

      <div className="dashboard-graphs">
        <div className="dashboard-column">
          {graficoCategoria && (
            <Plot
              data={graficoCategoria.data}
              layout={{
                ...graficoCategoria.layout,
                transition: { duration: 500, easing: "cubic-in-out" },
              }}
              config={{ displayModeBar: false }}
            />
          )}
        </div>
        <div className="dashboard-column">
          {graficoMarketplace && (
            <Plot
              data={graficoMarketplace.data}
              layout={{
                ...graficoMarketplace.layout,
                transition: { duration: 500, easing: "cubic-in-out" },
              }}
              config={{ displayModeBar: false }}
            />
          )}
        </div>
      </div>

      <div className="dashboard-full">
        {graficoMensal && (
          <Plot
            data={graficoMensal.data}
            layout={{
              ...graficoMensal.layout,
              transition: { duration: 500, easing: "cubic-in-out" },
            }}
            config={{ displayModeBar: false }}
          />
        )}
      </div>
    </div>
  );
}

function Card({ title, value, sub, color, isButton, isCurrency }) {
  return (
    <div className="dashboard-card">
      <p className="card-title">{title}</p>
      <p className={`card-value ${color}`}>
        <CountUp
          end={value}
          prefix={isCurrency ? "R$ " : ""}
          separator="."
          decimals={2}
          duration={1.4}
        />
      </p>
      {isButton ? (
        <button
          className="btn-ver"
          onClick={() => (window.location.href = "/notificacoes")}
        >
          Ver notificações
        </button>
      ) : (
        <p className="card-sub">{sub}</p>
      )}
    </div>
  );
}
