export default function MasterPanel() {
    return (
      <div style={{ padding: '2rem', color: 'white' }}>
        <h1>🛡️ Painel Master</h1>
        <p>Você está logado como administrador master.</p>
      </div>
    )
  }
  