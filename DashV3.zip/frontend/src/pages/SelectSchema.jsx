import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import api from '../services/api'
import './SelectSchema.css' // crie um css simples para estilizar se quiser

export default function SelectSchema() {
  const navigate = useNavigate()
  const [schemas, setSchemas] = useState([])
  const [selectedSchema, setSelectedSchema] = useState('')
  const [error, setError] = useState('')

  useEffect(() => {
    async function fetchSchemas() {
      try {
        const token = localStorage.getItem('token')
        const res = await api.get('/schemas', {
          headers: { Authorization: `Bearer ${token}` }
        })
        setSchemas(res.data)
      } catch (err) {
        console.error('Erro ao buscar schemas:', err)
        setError('Falha ao buscar schemas.')
      }
    }

    fetchSchemas()
  }, [])

  const handleConfirm = () => {
    if (!selectedSchema) {
      setError('Selecione um schema antes de continuar.')
      return
    }

    localStorage.setItem('schema', selectedSchema)
    navigate('/dashboard')
  }

  return (
    <div className="select-schema-container">
      <h2>📂 Escolha o schema para acessar:</h2>

      {error && <p className="error-msg">{error}</p>}

      <select value={selectedSchema} onChange={e => setSelectedSchema(e.target.value)}>
        <option value="">-- Selecione --</option>
        {schemas.map((s, i) => (
          <option key={i} value={s}>{s}</option>
        ))}
      </select>

      <button className="btn-confirm" onClick={handleConfirm}>
        Confirmar
      </button>
    </div>
  )
}
