export default function SemPermissao() {
    return (
      <div style={{ padding: 20, color: 'red' }}>
        <h1>🚫 Acesso Negado</h1>
        <p>Você não tem permissão para acessar esta calculadora.</p>
      </div>
    );
  }
  