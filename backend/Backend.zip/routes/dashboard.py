# backend/routes/dashboard.py

from fastapi import APIRouter, Request, HTTPException
from queries import (
    get_valor_total_faturado_query,
    get_valor_total_frete_query,
    get_valor_total_devolucao_query,
    get_total_produtos_sem_venda,
    get_categorias_query,
    get_faturamento_por_marketplace_query,
    get_faturamento_mensal_query
)
from utils import montar_grafico_barras, montar_grafico_linhas
from datetime import datetime, timedelta

router = APIRouter()

@router.get("/dashboard")
def dashboard(request: Request, start_date: str = None, end_date: str = None):
    print("##### STARTING DASHBOARD CALL #####")

    # 🛡️ Lê o schema enviado no header
    schema = request.headers.get("x-schema")
    if not schema:
        raise HTTPException(status_code=400, detail="Schema não fornecido no header")

    print(f"Schema recebido: {schema}")

    # 🛡️ Trata as datas corretamente
    if start_date and end_date:
        try:
            start = datetime.strptime(start_date, "%Y-%m-%d")
            end = datetime.strptime(end_date, "%Y-%m-%d")
        except ValueError:
            raise HTTPException(status_code=400, detail="Formato de data inválido, esperado yyyy-mm-dd")
    else:
        end = datetime.today()
        start = end - timedelta(days=30)

    start_str = start.strftime('%Y-%m-%d')
    end_str = end.strftime('%Y-%m-%d')

    print(f"Período filtrado: {start_str} até {end_str}")

    # 🔥 Calcula dinamicamente todos os KPIs
    try:
        valor_faturado = get_valor_total_faturado_query(schema, start_str, end_str)
        valor_frete = get_valor_total_frete_query(schema, start_str, end_str)
        valor_devolucao, qtd_devolucao = get_valor_total_devolucao_query(schema, start_str, end_str)
        produtos_sem_venda = get_total_produtos_sem_venda(schema, start_str, end_str)

        categorias = get_categorias_query(schema, start_str, end_str)
        marketplace = get_faturamento_por_marketplace_query(schema, start_str, end_str)
        grafico_mensal = montar_grafico_linhas(
            schema=schema,
            query_func=get_faturamento_mensal_query,
            campo_x="mes",
            campo_y="faturamento",
            titulo="Faturamento Mensal",
            start_date=start_str,
            end_date=end_str
        )

    except Exception as e:
        print(f"Erro ao calcular KPIs: {e}")
        raise HTTPException(status_code=500, detail="Erro ao calcular KPIs")

    # 🧠 Monta a resposta final com dados atualizados
    resposta = {
        "faturamento": {
            "valor_atual": float(valor_faturado),
            "indicador": None,
            "cor": None
        },
        "frete": {
            "valor_atual": float(valor_frete)
        },
        "devolucao": {
            "valor_atual": float(valor_devolucao),
            "qtd": int(qtd_devolucao)
        },
        "produtosSemVenda": int(produtos_sem_venda),
        "grafico_categoria": montar_grafico_barras(
            categorias, "categoria", "quantidade_total", "Distribuição por Categoria"
        ),
        "grafico_marketplace": montar_grafico_barras(
            marketplace, "marketplace", "valor_total", "Faturamento por Marketplace"
        ),
        "grafico_mensal": grafico_mensal,
    }

    print("##### FINALIZANDO DASHBOARD CALL #####")
    return resposta
